#SXD20|20011|50641|70210|2019.02.05 12:24:54|wd05-project-tokar|0|3|7|
#TA categories`2`16384|posts`2`16384|users`3`16384
#EOH

#	TC`categories`utf8mb4_unicode_520_ci	;
CREATE TABLE `categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cat_title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`categories`utf8mb4_unicode_520_ci	;
INSERT INTO `categories` VALUES 
(1,'Покупки')	;
#	TC`posts`utf8mb4_unicode_520_ci	;
CREATE TABLE `posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_520_ci,
  `autor_id` int(11) unsigned DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `post_img` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `post_img_small` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_foreignkey_posts_autor` (`autor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`posts`utf8mb4_unicode_520_ci	;
INSERT INTO `posts` VALUES 
(13,'Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 ','Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 Пост 1 ',4,'2019-02-04 16:51:31','1113163733.jpg','320-1113163733.jpg'),
(14,'Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2','Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2Пост 2',4,'2019-02-04 16:51:57','-677212432.jpg','320--677212432.jpg'),
(15,'Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 ','Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 Пост 3 ',4,'2019-02-04 16:52:16','1154851413.jpg','320-1154851413.jpg'),
(16,'Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 ','Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 Пост3 ',4,'2019-02-04 18:54:40',\N,\N),
(17,'Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 ','Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 Пост 5 ',4,'2019-02-04 19:00:31','345825777.jpg','320-345825777.jpg')	;
#	TC`users`utf8mb4_unicode_520_ci	;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `surname` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `avatar_small` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `recovery_code` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `recovery_code_times` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`users`utf8mb4_unicode_520_ci	;
INSERT INTO `users` VALUES 
(4,'dmtokfl@gmail.com','$2y$10$qYhhszQsrADzCflq1KzyzupvnJBfGBKAVEuw2EtxwGBZ0a4jCds6.','admin','Дмитрий','Токарь','Россия','Москва','-251025578.jpg','48--251025578.jpg','VZ1RxjX9QGAOzig',0),
(5,'dmtr3243@gmail.com','$2y$10$7ORW2oot0TfbgkIoaMLWTOPLn.f5bfRBGA/a614WNaPQZm3pjs/lC','user','Андрей','Андреев','Россия','Санкт-Петербург','-494332196.jpg','48--494332196.jpg','r8kRosf2Gd3cUV9',2),
(6,'mail@mail.com','$2y$10$6XhOBewB8Me5fWzHicljSeRHzZOgtupRzztJ7iAyO3nPe/Nq6R5C.','user','Иван','Иванов','Россия','Москва','468042433.jpg','48-468042433.jpg',\N,\N)	;
